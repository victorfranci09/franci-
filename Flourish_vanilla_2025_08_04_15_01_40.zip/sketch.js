function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}function setup() {
  createCanvas(800, 400);
}

function draw() {
  // Céu
  background(135, 206, 235);

  // Sol
  fill(255, 204, 0);
  noStroke();
  ellipse(700, 80, 100, 100);

  // Montanhas
  fill(150);
  triangle(100, 300, 300, 100, 500, 300);
  fill(120);
  triangle(300, 300, 500, 120, 700, 300);

  // Grama
  fill(34, 139, 34);
  rect(0, 300, width, 100);

  // Árvores
  drawTree(150, 280);
  drawTree(250, 280);
  drawTree(600, 280);
}

// Função para desenhar uma árvore
function drawTree(x, y) {
  // Tronco
  fill(101, 67, 33);
  rect(x, y, 20, 40);
  
  // Copa
  fill(34, 139, 34);
  ellipse(x + 10, y - 10, 60, 60);
}